// Copyright 2015, Joe Tsai. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE.md file.

// +build debug,!gofuzz

package internal

const (
	Debug  = true
	GoFuzz = false
)
