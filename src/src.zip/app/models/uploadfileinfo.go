package models

// 配制上传的文件和运行文件的路径信息
type Uploadfile struct {
	Tempfilepath  string
	Runtimepath  string
}